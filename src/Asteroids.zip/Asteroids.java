/*
CLASS: Asteroids
DESCRIPTION: Extending Game, Asteroids is all in the paint method.
NOTE: This class is the metaphorical "main method" of your program,
      it is your control center.
Original code by Dan Leyzberg and Art Simon
 */
import java.awt.*;
import java.util.*;
import java.awt.event.KeyListener;
import java.util.ArrayList;

public class Asteroids extends Game {
	public static final int SCREEN_WIDTH = 800;
	public static final int SCREEN_HEIGHT = 600;
	
	boolean safePeriod = false;
	int lives = 6;
	
	boolean dimming = true;
	boolean brightening = false;
	Color color = new Color(0, 0, 255);

	static int counter = 0;
	static int counter2 = -110;
	
	private Ship ship;

	private java.util.List<Asteroid> randomAsteroids = new ArrayList<Asteroid>();
	private java.util.List<SmallAsteroid> SmallAsteroids = new ArrayList<SmallAsteroid>();
	private Star[] randomStars;
	private java.util.ArrayList<Bullet> outOfBoundBullets = new ArrayList<Bullet>();
	private java.util.ArrayList<Asteroid> collidedAsteroids = new ArrayList<Asteroid>();
	private java.util.ArrayList<SmallAsteroid> collidedSmallAsteroids = new ArrayList<SmallAsteroid>();

	public Asteroids() {
		super("Asteroids!",SCREEN_WIDTH,SCREEN_HEIGHT);
		this.setFocusable(true);
		this.requestFocus();
		
		// create a number of random asteroid objects
		randomAsteroids = createRandomAsteroids(5,50,30);
		randomStars = createStars(20,10);
		ship = createShip();
		this.addKeyListener(ship);
		

	}

	private Ship createShip()
	{
		Point[] shipShape = {
                new Point(0, 0),
                new Point(Ship.SHIP_WIDTH/3.5, Ship.SHIP_HEIGHT/2),
                new Point(0, Ship.SHIP_HEIGHT),
                new Point(Ship.SHIP_WIDTH, Ship.SHIP_HEIGHT/2)
        };
		Point startingPosition = new Point((width -Ship.SHIP_WIDTH)/2, (height - Ship.SHIP_HEIGHT)/2);
        int startingRotation = 0; // Start facing to the right

        return new Ship(shipShape, startingPosition, startingRotation);
	}
	//  Create an array of random asteroids
	private java.util.List<Asteroid> createRandomAsteroids(int numberOfAsteroids, int maxAsteroidWidth,
			int minAsteroidWidth) {
		java.util.List<Asteroid> asteroids = new ArrayList<>(numberOfAsteroids);

		for(int i = 0; i < numberOfAsteroids; ++i) {
			// Create random asteroids by sampling points on a circle
			// Find the radius first.
			int radius = (int) (Math.random() * maxAsteroidWidth);
			if(radius < minAsteroidWidth) {
				radius += minAsteroidWidth;
			}
			// Find the circles angle
			double angle = (Math.random() * Math.PI * 1.0/2.0);
			if(angle < Math.PI * 1.0/5.0) {
				angle += Math.PI * 1.0/5.0;
			}
			// Sample and store points around that circle
			ArrayList<Point> asteroidSides = new ArrayList<Point>();
			double originalAngle = angle;
			while(angle < 2*Math.PI) {
				double x = Math.cos(angle) * radius;
				double y = Math.sin(angle) * radius;
				asteroidSides.add(new Point(x, y));
				angle += originalAngle;
			}
			// Set everything up to create the asteroid
			Point[] inSides = asteroidSides.toArray(new Point[asteroidSides.size()]);
			Point inPosition = new Point(Math.random() * SCREEN_WIDTH, Math.random() * SCREEN_HEIGHT);
			double inRotation = Math.random() * 360;
			asteroids.add(new Asteroid(inSides, inPosition, inRotation));
		}
		return asteroids;
	}
	
	private SmallAsteroid createSmallAsteroid(Point position, int maxAsteroidWidth, int minAsteroidWidth, int number) {
			// Create random asteroids by sampling points on a circle
			// Find the radius first.
			int radius = (int) (Math.random() * maxAsteroidWidth);
			if(radius < minAsteroidWidth) {
				radius += minAsteroidWidth;
			}
			// Find the circles angle
			double angle = (Math.random() * Math.PI * 1.0/2.0);
			if(angle < Math.PI * 1.0/5.0) {
				angle += Math.PI * 1.0/5.0;
			}
			// Sample and store points around that circle
			ArrayList<Point> asteroidSides = new ArrayList<Point>();
			double originalAngle = angle;
			while(angle < 2*Math.PI) {
				double x = Math.cos(angle) * radius;
				double y = Math.sin(angle) * radius;
				asteroidSides.add(new Point(x, y));
				angle += originalAngle;
			}
			// Set everything up to create the asteroid
			Point[] inSides = asteroidSides.toArray(new Point[asteroidSides.size()]);
			double inRotation = Math.random() * 360;
			SmallAsteroid smallAsteroid = new SmallAsteroid(inSides, position, inRotation, number);
			return smallAsteroid;
	}
	
	public Star[] createStars(int numberOfStars, int maxRadius) {
	 	Star[] stars = new Star[numberOfStars];
	 	for(int i = 0; i < numberOfStars; ++i) {
	 		Point center = new Point
	(Math.random() * SCREEN_WIDTH, Math.random() * SCREEN_HEIGHT);


	 		int radius = (int) (Math.random() * maxRadius);
	 		if(radius < 1) {
	 			radius = 1;
	 		}
	 		stars[i] = new Star(center, radius);
	 	}
	return stars;
	 }

	public void paint(Graphics brush) {
		brush.setColor(Color.black);
		brush.fillRect(0,0,width,height);

		// sample code for printing message for debugging
		// counter is incremented and this message printed
		// each time the canvas is repainted
		counter++;
		brush.setColor(Color.white);
		brush.drawString("Counter is " + counter,10,10);
		
		if(dimming)
		{
			color = new Color(0, 0, color.getBlue() - 5);
			if(color.getBlue() < 100)
			{
				dimming = false;
				brightening = true;
			}
		}
		else if(brightening)
		{
			color = new Color(0, 0, color.getBlue() + 5);
			if(color.getBlue() > 250)
			{
				dimming = true;
				brightening = false;
			}
		}
		
		for (Star star : randomStars) {
			star.paint(brush,color);
		}
		// display the random asteroids
		for (Asteroid asteroid : randomAsteroids) {
			asteroid.paint(brush,Color.white);
			asteroid.move();
			if(asteroid.collision(ship) && !safePeriod)
			{
				counter2 = counter;
				safePeriod = true;
				lives--;
			}
		}
		for(SmallAsteroid smallAsteroid : SmallAsteroids)
		{
			smallAsteroid.paint(brush, Color.white);
			smallAsteroid.move();
			if(smallAsteroid.collision(ship) && !safePeriod)
			{
				counter2 = counter;
				safePeriod = true;
				lives--;
			}
		}
		if(counter - counter2 < 50)
		{
			ship.paint(brush,Color.red);
		}
		else
		{
			ship.paint(brush,Color.white);	
			safePeriod = false;
		}
		ship.move();
		for(Bullet bullet : ship.getBullets())
		{
			bullet.paint(brush, Color.green);
			bullet.move();
			if(bullet.outOfBounds())
			{
				outOfBoundBullets.add(bullet);
			}
			for(Asteroid asteroid : randomAsteroids)
			{
				if(asteroid.contains(bullet.getCenter()))
				{
					collidedAsteroids.add(asteroid);
					outOfBoundBullets.add(bullet);
					SmallAsteroid a1 = createSmallAsteroid(new Point(asteroid.position.x-20, asteroid.position.y-20),10,20, 1);
					SmallAsteroid a2 = createSmallAsteroid(new Point(asteroid.position.x+20, asteroid.position.y-20),10,20, 2);
					SmallAsteroid a3 = createSmallAsteroid(new Point(asteroid.position.x-20, asteroid.position.y+20),10,20, 3);
					SmallAsteroid a4 = createSmallAsteroid(new Point(asteroid.position.x+20, asteroid.position.y+20),10,20, 4);
					SmallAsteroids.add(a1);
					SmallAsteroids.add(a2);
					SmallAsteroids.add(a3);
					SmallAsteroids.add(a4);
				}
			}
			for(SmallAsteroid smallAsteroid : SmallAsteroids)
			{
				if(smallAsteroid.contains(bullet.getCenter()))
				{
					collidedSmallAsteroids.add(smallAsteroid);
					outOfBoundBullets.add(bullet);
				}
			}
			}
		for(Bullet bullet : outOfBoundBullets)
		{
			ship.getBullets().remove(bullet);
		}
		for(Asteroid asteroid : collidedAsteroids)
		{
			randomAsteroids.remove(asteroid);
		}
		for(SmallAsteroid smallAsteroid : collidedSmallAsteroids)
		{
			SmallAsteroids.remove(smallAsteroid);
		}
		
		if(randomAsteroids.isEmpty() && SmallAsteroids.isEmpty())
		{
			brush.setColor(Color.black);
			brush.fillRect(0,0,width,height);
			brush.setColor(Color.blue);
			brush.drawString("You Win", SCREEN_WIDTH/2 - 25, SCREEN_HEIGHT/2);
		}
		if(lives == 0)
		{
			while(!randomAsteroids.isEmpty())
			{
				randomAsteroids.remove(0);
			}
			brush.setColor(Color.black);
			brush.fillRect(0,0,width,height);
			brush.setColor(Color.red);
			brush.drawString("You Lost", SCREEN_WIDTH/2 - 25, SCREEN_HEIGHT/2);
		}
	}

	public static void main (String[] args) {
		Asteroids a = new Asteroids();
		a.repaint();
	}
}