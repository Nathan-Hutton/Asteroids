import java.awt.Color;
import java.awt.Graphics;

public class Bullet extends Circle {
	public static final int RADIUS = 8;
	private double rotation;
	
	public Bullet(Point center, double rotation) {
    	super(center, RADIUS);
    	this.rotation = rotation;
    }

	public void paint(Graphics brush, Color color) {
		brush.setColor(color);
		brush.fillOval((int)center.x, (int)center.y, radius, radius);
	}

	public void move() {
		center.x += 12 * Math.cos(Math.toRadians(rotation));
		center.y += 12 * Math.sin(Math.toRadians(rotation));
	}
	public boolean outOfBounds()
	{
		if(center.x > Asteroids.SCREEN_WIDTH || center.y > Asteroids.SCREEN_HEIGHT)
		{
			return true;			
		}
		return false;
	}
	public Point getCenter()
	{
		return center;
	}

}
